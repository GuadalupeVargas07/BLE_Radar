<?php
// Configuración de la Base de Datos
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'reto_ble_radar');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// ENCABEZADOS GLOBAL DE CORS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Max-Age: 86400"); // Cache de Preflight por 24 horas

// CAPTURA INMEDIATA DE PETICIONES PREFLIGHT HTTP OPTIONS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit(); // Finaliza la ejecución inmediatamente para no tocar la BD ni ejecutar lógica pesada
}