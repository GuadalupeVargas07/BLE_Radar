<?php
// Función auxiliar para responder JSON con la estructura del contrato
function sendResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    header("Content-Type: application/json; charset=UTF-8");
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit();
}

// Helper para responder errores rápido
function sendError($message, $statusCode = 400) {
    sendResponse([
        "success" => false,
        "error" => $message
    ], $statusCode);
}

// Función auxiliar para leer el cuerpo JSON de la petición
function getJsonInput() {
    $input = file_get_contents('php://input');
    return json_decode($input, true) ?? [];
}