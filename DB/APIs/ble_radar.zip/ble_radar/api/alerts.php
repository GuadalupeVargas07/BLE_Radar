<?php
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../utils.php';

$pdo = getDB();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $stmt = $pdo->query("SELECT a.*, d.name AS device_name, d.mac_address 
                             FROM alerts a 
                             JOIN devices d ON a.device_id = d.id 
                             ORDER BY a.created_at DESC");
        sendResponse(["status" => "success", "data" => $stmt->fetchAll()]);
        break;

    case 'POST':
        $data = getJsonInput();
        if (empty($data['device_id']) || empty($data['alert_type']) || empty($data['message'])) {
            sendResponse(["status" => "error", "message" => "Campos faltantes para generar alerta"], 400);
        }

        $stmt = $pdo->prepare("INSERT INTO alerts (device_id, alert_type, message) VALUES (?, ?, ?)");
        $stmt->execute([
            $data['device_id'],
            $data['alert_type'],
            $data['message']
        ]);

        sendResponse(["status" => "success", "id" => $pdo->lastInsertId()], 201);
        break;

    case 'PUT':
        // Marcar alerta como resuelta
        $data = getJsonInput();
        if (empty($data['id'])) {
            sendResponse(["status" => "error", "message" => "ID de alerta requerido"], 400);
        }

        $stmt = $pdo->prepare("UPDATE alerts SET is_resolved = ? WHERE id = ?");
        $stmt->execute([
            isset($data['is_resolved']) ? (int)$data['is_resolved'] : 1,
            $data['id']
        ]);

        sendResponse(["status" => "success", "message" => "Alerta actualizada"]);
        break;

    default:
        sendResponse(["status" => "error", "message" => "Método no permitido"], 405);
}