<?php
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../utils.php';

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$pdo = getDB();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $stmt = $pdo->prepare("SELECT * FROM devices WHERE id = ?");
            $stmt->execute([$_GET['id']]);
            $device = $stmt->fetch();
            if ($device) {
                sendResponse(["success" => true, "data" => $device], 200);
            } else {
                sendError("Dispositivo no encontrado", 404);
            }
        } else {
            $stmt = $pdo->query("SELECT * FROM devices ORDER BY id DESC");
            sendResponse(["success" => true, "data" => $stmt->fetchAll()], 200);
        }
        break;

    case 'POST':
        $data = getJsonInput();
        if (empty($data['mac_address'])) {
            sendError("El parámetro mac_address es requerido", 400);
        }

        try {
            $sql = "INSERT INTO devices (mac_address, name, device_type, tx_power, is_tracked) VALUES (?, ?, ?, ?, ?)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $data['mac_address'],
                $data['name'] ?? 'Dispositivo Desconocido',
                $data['device_type'] ?? 'Unknown',
                $data['tx_power'] ?? -59,
                isset($data['is_tracked']) ? (int)$data['is_tracked'] : 1
            ]);

            sendResponse([
                "success" => true,
                "data" => [
                    "id" => (int)$pdo->lastInsertId()
                ]
            ], 201);
        } catch (PDOException $e) {
            sendError("Error al registrar el dispositivo: " . $e->getMessage(), 500);
        }
        break;

    case 'PUT':
        $data = getJsonInput();
        if (empty($data['id'])) {
            sendError("El parámetro id es requerido para actualizar", 400);
        }

        $sql = "UPDATE devices SET name = ?, device_type = ?, tx_power = ?, is_tracked = ? WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $data['name'] ?? 'Dispositivo Desconocido',
            $data['device_type'] ?? 'Unknown',
            $data['tx_power'] ?? -59,
            isset($data['is_tracked']) ? (int)$data['is_tracked'] : 1,
            $data['id']
        ]);

        sendResponse(["success" => true, "data" => "Dispositivo actualizado correctamente"], 200);
        break;

    case 'DELETE':
        $id = $_GET['id'] ?? getJsonInput()['id'] ?? null;
        if (!$id) {
            sendError("El parámetro id es requerido", 400);
        }

        $stmt = $pdo->prepare("DELETE FROM devices WHERE id = ?");
        $stmt->execute([$id]);
        sendResponse(["success" => true, "data" => "Dispositivo eliminado correctamente"], 200);
        break;

    default:
        sendError("Método no permitido", 405);
}