<?php
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../utils.php';

$pdo = getDB();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $stmt = $pdo->query("SELECT id, name, email, role, created_at FROM users");
        sendResponse(["status" => "success", "data" => $stmt->fetchAll()]);
        break;

    case 'POST':
        $data = getJsonInput();
        if (empty($data['name']) || empty($data['email']) || empty($data['password'])) {
            sendResponse(["status" => "error", "message" => "Todos los campos son obligatorios"], 400);
        }

        $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);

        try {
            $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
            $stmt->execute([
                $data['name'],
                $data['email'],
                $hashedPassword,
                $data['role'] ?? 'user'
            ]);
            sendResponse(["status" => "success", "id" => $pdo->lastInsertId()], 201);
        } catch (PDOException $e) {
            sendResponse(["status" => "error", "message" => "El correo ya está registrado"], 400);
        }
        break;

    default:
        sendResponse(["status" => "error", "message" => "Método no permitido"], 405);
}