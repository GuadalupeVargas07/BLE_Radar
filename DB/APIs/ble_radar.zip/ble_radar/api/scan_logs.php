<?php
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../utils.php';

$pdo = getDB();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $deviceId = $_GET['device_id'] ?? null;
        if ($deviceId) {
            $stmt = $pdo->prepare("SELECT s.*, d.mac_address, d.name AS device_name, l.name AS location_name 
                                   FROM scan_logs s 
                                   JOIN devices d ON s.device_id = d.id 
                                   LEFT JOIN locations l ON s.location_id = l.id 
                                   WHERE s.device_id = ? 
                                   ORDER BY s.scanned_at DESC LIMIT 100");
            $stmt->execute([$deviceId]);
        } else {
            $stmt = $pdo->query("SELECT s.*, d.mac_address, d.name AS device_name, l.name AS location_name 
                                 FROM scan_logs s 
                                 JOIN devices d ON s.device_id = d.id 
                                 LEFT JOIN locations l ON s.location_id = l.id 
                                 ORDER BY s.scanned_at DESC LIMIT 100");
        }
        sendResponse(["status" => "success", "data" => $stmt->fetchAll()]);
        break;

    case 'POST':
        $data = getJsonInput();
        if (empty($data['device_id']) || !isset($data['rssi'])) {
            sendResponse(["status" => "error", "message" => "device_id y rssi son requeridos"], 400);
        }

        $sql = "INSERT INTO scan_logs (device_id, location_id, rssi, estimated_distance) VALUES (?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $data['device_id'],
            $data['location_id'] ?? null,
            $data['rssi'],
            $data['estimated_distance'] ?? null
        ]);

        sendResponse([
            "status" => "success",
            "message" => "Escaneo registrado",
            "id" => $pdo->lastInsertId()
        ], 201);
        break;

    default:
        sendResponse(["status" => "error", "message" => "Método no permitido"], 405);
}