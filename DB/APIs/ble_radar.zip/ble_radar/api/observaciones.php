<?php
require_once __DIR__ . '/../config.php'; // Incluye la captura de OPTIONS y CORS
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../utils.php';

$pdo = getDB();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        try {
            $stmt = $pdo->query("SELECT id, device_id, nombre, rssi, nota, creado_en FROM observaciones ORDER BY creado_en DESC");
            sendResponse([
                "success" => true,
                "data" => $stmt->fetchAll()
            ], 200);
        } catch (PDOException $e) {
            sendError("Error al consultar observaciones: " . $e->getMessage(), 500);
        }
        break;

    case 'POST':
        $data = getJsonInput();

        // Validaciones requeridas y compatibilidad
        $deviceId = isset($data['device_id']) && trim($data['device_id']) !== '' 
            ? trim($data['device_id']) 
            : (isset($data['dispositivoId']) ? trim($data['dispositivoId']) : '');
            
        $nota = isset($data['nota']) && trim($data['nota']) !== '' 
            ? trim($data['nota']) 
            : 'Observación BLE registrada';

        if ($deviceId === '') {
            sendError("El campo 'device_id' o 'dispositivoId' es obligatorio.", 400);
        }

        // Privacidad y Manejo de Nulos
        $nombre = (isset($data['nombre']) && trim($data['nombre']) !== '') ? trim($data['nombre']) : null;
        $rssi   = (isset($data['rssi']) && $data['rssi'] !== '' && $data['rssi'] !== null) ? (int)$data['rssi'] : null;

        try {
            $stmt = $pdo->prepare("INSERT INTO observaciones (device_id, nombre, rssi, nota) VALUES (?, ?, ?, ?)");
            $stmt->execute([$deviceId, $nombre, $rssi, $nota]);

            sendResponse([
                "success" => true,
                "data" => [
                    "id" => (int)$pdo->lastInsertId()
                ]
            ], 201);
        } catch (PDOException $e) {
            sendError("Error al guardar la observación: " . $e->getMessage(), 500);
        }
        break;

    default:
        sendError("Método no permitido. Utilice GET o POST.", 405);
}