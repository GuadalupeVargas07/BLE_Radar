<?php
// Permitir conexiones desde la app Ionic (CORS)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json; charset=UTF-8");

// Manejar las peticiones pre-flight de los navegadores/dispositivos
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Respuesta exitosa para la prueba de conexión
http_response_code(200);
echo json_encode(["status" => "ok", "message" => "Conexión exitosa al servidor PHP"]);
?>