<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../utils.php';

// Validar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError("Método no permitido. Utilice POST con FormData.", 405);
}

// 1. Detectar si la clave viene como 'archivo' o 'Archivo'
$fileKey = null;
if (isset($_FILES['archivo'])) {
    $fileKey = 'archivo';
} elseif (isset($_FILES['Archivo'])) {
    $fileKey = 'Archivo';
}

if (!$fileKey || $_FILES[$fileKey]['error'] !== UPLOAD_ERR_OK) {
    sendError("No se recibió ningún archivo bajo la clave 'archivo' o se produjo un error al subirlo.", 400);
}

$file = $_FILES[$fileKey];

// 2. Validar tamaño máximo (8 MB)
$maxSizeBytes = 8 * 1024 * 1024;
if ($file['size'] > $maxSizeBytes) {
    sendError("El archivo supera el límite máximo permitido de 8 MB.", 400);
}

// 3. Restringir extensiones y tipos MIME permitidos
$allowedMimeTypes = [
    'image/jpeg', 'image/png', 'image/webp',
    'audio/mpeg', 'audio/wav', 'audio/ogg', 'audio/mp4', 'audio/m4a', 'audio/aac'
];
$allowedExtensions = ['jpg', 'jpeg', 'png', 'webp', 'mp3', 'wav', 'ogg', 'm4a', 'aac'];

$extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

$finfo = finfo_open(FILEINFO_MIME_TYPE);
$detectedMimeType = finfo_file($finfo, $file['tmp_name']);
finfo_close($finfo);

if (!in_array($detectedMimeType, $allowedMimeTypes) || !in_array($extension, $allowedExtensions)) {
    sendError("Tipo de archivo no permitido. Solo se permiten imágenes (JPG, PNG, WEBP) y audios (MP3, WAV, OGG, M4A).", 400);
}

// 4. Mover a la carpeta uploads
$uploadDir = __DIR__ . '/../uploads/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

$uniqueName = bin2hex(random_bytes(10)) . '_' . time() . '.' . $extension;
$targetPath = $uploadDir . $uniqueName;

if (move_uploaded_file($file['tmp_name'], $targetPath)) {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https" : "http";
    $host = $_SERVER['HTTP_HOST'];
    $fileUrl = "{$protocol}://{$host}/ble_radar/uploads/{$uniqueName}";

    sendResponse([
        "success" => true,
        "data" => [
            "file_name" => $uniqueName,
            "original_name" => $file['name'],
            "mime_type" => $detectedMimeType,
            "size_bytes" => $file['size'],
            "url" => $fileUrl
        ]
    ], 201);
} else {
    sendError("Ocurrió un error al guardar el archivo en el servidor.", 500);
}