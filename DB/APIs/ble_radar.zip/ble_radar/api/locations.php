<?php
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../utils.php';

$pdo = getDB();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $stmt = $pdo->query("SELECT * FROM locations ORDER BY id ASC");
        sendResponse(["status" => "success", "data" => $stmt->fetchAll()]);
        break;

    case 'POST':
        $data = getJsonInput();
        if (empty($data['name'])) {
            sendResponse(["status" => "error", "message" => "El nombre es requerido"], 400);
        }

        $stmt = $pdo->prepare("INSERT INTO locations (name, description, floor) VALUES (?, ?, ?)");
        $stmt->execute([
            $data['name'],
            $data['description'] ?? null,
            $data['floor'] ?? '1'
        ]);

        sendResponse(["status" => "success", "id" => $pdo->lastInsertId()], 201);
        break;

    default:
        sendResponse(["status" => "error", "message" => "Método no permitido"], 405);
}